# VM1 - SDN Controller (OS-Ken) + Hybrid RR/GA Load Balancer

This package runs the SDN controller described in the proposal.

Implementation note: Ryu's latest PyPI release is old (2020) and does not install cleanly on Ubuntu 22.04 / Python 3.10.
This project uses **OS-Ken** (OpenStack-maintained fork of Ryu) to provide the same OpenFlow controller APIs, but with
modern Python compatibility.
- VIP-based load balancing (Round Robin decisions, GA periodic optimization)
- Flow rule installation (OpenFlow 1.3)
- Monitoring loop + Prometheus metrics + REST API

It is intended to be deployed on a dedicated "Controller VM" (OpenStack instance or bare metal).
