# VM1 - SDN Controller (Ryu) + Hybrid RR/GA Load Balancer

This package runs the SDN controller described in the proposal:
- VIP-based load balancing (Round Robin decisions, GA periodic optimization)
- Flow rule installation (OpenFlow 1.3)
- Monitoring loop + Prometheus metrics + REST API

It is intended to be deployed on a dedicated "Controller VM" (OpenStack instance or bare metal).
