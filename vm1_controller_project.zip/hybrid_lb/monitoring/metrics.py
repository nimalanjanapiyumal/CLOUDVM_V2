from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional

from prometheus_client import Counter, Gauge, start_http_server

from hybrid_lb.model import Backend


LB_DECISIONS_TOTAL = Counter(
    "hybrid_lb_decisions_total",
    "Total number of load-balancing decisions made by the controller",
    labelnames=("backend_id", "service_port"),
)

BACKEND_WEIGHT = Gauge(
    "hybrid_lb_backend_weight",
    "Current effective weight for a backend (GA output)",
    labelnames=("backend_id",),
)

BACKEND_ACTIVE_FLOWS = Gauge(
    "hybrid_lb_backend_active_flows",
    "Active flows mapped to a backend (controller view)",
    labelnames=("backend_id",),
)

BACKEND_MBPS_OUT = Gauge(
    "hybrid_lb_backend_mbps_out",
    "Backend egress throughput (Mbps) as seen by port stats",
    labelnames=("backend_id",),
)

BACKEND_MBPS_IN = Gauge(
    "hybrid_lb_backend_mbps_in",
    "Backend ingress throughput (Mbps) as seen by port stats",
    labelnames=("backend_id",),
)

GA_LAST_RUN_TS = Gauge(
    "hybrid_lb_ga_last_run_timestamp",
    "Unix timestamp of last GA weight update",
)

SWITCH_CONNECTED = Gauge(
    "hybrid_lb_switch_connected",
    "Whether at least one datapath is connected (1=yes, 0=no)",
)


def start_metrics_server(port: int = 9100) -> None:
    """Start the Prometheus metrics HTTP server."""
    start_http_server(port)


def update_backend_metrics(backends: List[Backend]) -> None:
    for b in backends:
        BACKEND_WEIGHT.labels(b.backend_id).set(b.effective_weight())
        BACKEND_ACTIVE_FLOWS.labels(b.backend_id).set(b.stats.active_flows)
        BACKEND_MBPS_OUT.labels(b.backend_id).set(b.stats.bps_out / 1_000_000.0)
        BACKEND_MBPS_IN.labels(b.backend_id).set(b.stats.bps_in / 1_000_000.0)


def mark_ga_run(ts: Optional[float] = None) -> None:
    GA_LAST_RUN_TS.set(ts if ts is not None else time.time())
