from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

from prometheus_client import Gauge


@dataclass
class Metrics:
    backend_weight: Gauge
    backend_mbps_tx: Gauge
    backend_mbps_rx: Gauge
    backend_active_flows: Gauge
    ga_last_runtime_seconds: Gauge
    ga_last_run_timestamp: Gauge


def create_metrics() -> Metrics:
    backend_weight = Gauge("hybrid_lb_backend_weight", "Current backend integer weight", ["backend"])
    backend_mbps_tx = Gauge("hybrid_lb_backend_mbps_tx", "Estimated Mbps TX (port stats delta)", ["backend"])
    backend_mbps_rx = Gauge("hybrid_lb_backend_mbps_rx", "Estimated Mbps RX (port stats delta)", ["backend"])
    backend_active_flows = Gauge("hybrid_lb_backend_active_flows", "Active flows (approx.)", ["backend"])
    ga_last_runtime_seconds = Gauge("hybrid_lb_ga_last_runtime_seconds", "GA last runtime seconds")
    ga_last_run_timestamp = Gauge("hybrid_lb_ga_last_run_timestamp", "Unix timestamp of GA last run")
    return Metrics(
        backend_weight=backend_weight,
        backend_mbps_tx=backend_mbps_tx,
        backend_mbps_rx=backend_mbps_rx,
        backend_active_flows=backend_active_flows,
        ga_last_runtime_seconds=ga_last_runtime_seconds,
        ga_last_run_timestamp=ga_last_run_timestamp,
    )
