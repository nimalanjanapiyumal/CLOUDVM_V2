from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from .rr import RoundRobin, SmoothWeightedRoundRobin
from .genetic import GAConfig, GeneticOptimizer


@dataclass
class GatingThresholds:
    max_mbps_tx: float = 95.0
    max_mbps_rx: float = 95.0
    max_active_flows: int = 5000


class HybridLoadBalancer:
    """Hybrid policy:
    - Fast per-flow decisions via RR / Smooth Weighted RR.
    - Long-term optimizer (GA) periodically updates weights.
    - Gating prevents sending traffic to overloaded backends even if GA prefers them.
    """

    def __init__(
        self,
        rr_mode: str = "smooth_weighted",
        ga_enabled: bool = True,
        ga_cfg: Optional[GAConfig] = None,
        gating: Optional[GatingThresholds] = None,
    ) -> None:
        self.rr_mode = rr_mode
        self.ga_enabled = ga_enabled
        self.ga_cfg = ga_cfg or GAConfig()
        self.gating = gating or GatingThresholds()

        self._rr = RoundRobin()
        self._swrr = SmoothWeightedRoundRobin()
        self._weights: Dict[str, int] = {}  # backend_id -> int weight

    @property
    def weights(self) -> Dict[str, int]:
        return dict(self._weights)

    def set_weights(self, weights: Dict[str, int]) -> None:
        # keep only positive ints
        self._weights = {k: int(v) for k, v in weights.items() if int(v) > 0}

    def ga_optimize(self, backend_ids: List[str], loads_mbps: List[float]) -> Dict[str, int]:
        if not self.ga_enabled:
            return self.weights
        opt = GeneticOptimizer(self.ga_cfg)
        return opt.optimize(backend_ids, loads_mbps)

    def choose_backend(
        self,
        backend_ids: List[str],
        *,
        base_weights: Dict[str, int],
        live_load: Dict[str, Tuple[float, float, int]],  # id -> (mbps_tx, mbps_rx, active_flows)
    ) -> Optional[str]:
        # Apply gating
        allowed: List[str] = []
        for bid in backend_ids:
            tx, rx, flows = live_load.get(bid, (0.0, 0.0, 0))
            if (tx <= self.gating.max_mbps_tx) and (rx <= self.gating.max_mbps_rx) and (flows <= self.gating.max_active_flows):
                allowed.append(bid)

        if not allowed:
            # If everything is overloaded, fall back to all (avoid blackholing)
            allowed = backend_ids[:]

        if self.rr_mode == "round_robin":
            return self._rr.choose(allowed)

        # smooth weighted RR: combine GA weights (if present) with base weights
        weights: Dict[str, int] = {}
        for bid in allowed:
            w = base_weights.get(bid, 1)
            if self._weights.get(bid, 0) > 0:
                w = max(1, int(round(w * self._weights[bid])))
            weights[bid] = max(1, int(w))

        return self._swrr.choose(weights)
