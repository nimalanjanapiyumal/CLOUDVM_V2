from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

from hybrid_lb.algorithms.rr import SmoothWeightedRoundRobin
from hybrid_lb.model import Backend


@dataclass
class Thresholds:
    max_active_flows: int = 200
    max_mbps_out: float = 900.0  # very high default to avoid false blocks in emulation


class HybridLoadBalancer:
    """Hybrid strategy: fast per-flow SWRR + periodic GA recompute.

    Conflict resolution rule:
      If a backend is above thresholds (active flows or Mbps), it is treated as temporarily unavailable,
      regardless of GA weight.
    """

    def __init__(self, thresholds: Thresholds | None = None) -> None:
        self.thresholds = thresholds or Thresholds()
        self._swrr = SmoothWeightedRoundRobin()
        self.last_ga_ts: float = 0.0

    def update_thresholds(self, max_active_flows: Optional[int] = None, max_mbps_out: Optional[float] = None) -> None:
        if max_active_flows is not None:
            self.thresholds.max_active_flows = int(max_active_flows)
        if max_mbps_out is not None:
            self.thresholds.max_mbps_out = float(max_mbps_out)

    def apply_ga_weights(self, backends: Sequence[Backend], weights: Sequence[int]) -> None:
        for b, w in zip(backends, weights):
            b.ga_weight = int(max(1, w))
        self.last_ga_ts = time.time()

    def _is_overloaded(self, b: Backend) -> bool:
        if b.stats.active_flows > self.thresholds.max_active_flows:
            return True
        mbps_out = b.stats.bps_out / 1_000_000.0
        if mbps_out > self.thresholds.max_mbps_out:
            return True
        return False

    def choose_backend(self, backends: List[Backend]) -> Backend:
        if not backends:
            raise ValueError("No backends configured")

        # Apply overload gating.
        gated = []
        for b in backends:
            if not b.enabled:
                continue
            if self._is_overloaded(b):
                continue
            gated.append(b)

        if not gated:
            # Fallback: choose least loaded enabled backend.
            enabled = [b for b in backends if b.enabled]
            if not enabled:
                raise ValueError("No enabled backends")
            return min(enabled, key=lambda x: (x.stats.active_flows, x.stats.bps_out))

        # Fast per-flow selection (SWRR respects GA weights).
        return self._swrr.choose(gated)
