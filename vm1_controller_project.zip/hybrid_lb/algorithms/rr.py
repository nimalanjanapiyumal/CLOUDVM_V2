from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from typing import Iterable, List, Optional, Sequence, Tuple, TypeVar

from hybrid_lb.model import Backend

T = TypeVar("T")


class RoundRobin:
    """Simple round robin selector."""

    def __init__(self) -> None:
        self._cycle = None  # type: Optional[Iterable[int]]
        self._last_n = None  # type: Optional[int]
        self._idx = 0

    def choose_index(self, n: int) -> int:
        if n <= 0:
            raise ValueError("n must be > 0")
        # Keep a simple modulo counter (predictable, fast).
        self._idx = (self._idx + 1) % n
        return self._idx

    def choose(self, items: Sequence[T]) -> T:
        if not items:
            raise ValueError("items must be non-empty")
        idx = self.choose_index(len(items))
        return items[idx]


@dataclass
class SmoothWeightedRoundRobin:
    """Smooth Weighted Round Robin (SWRR).

    This is used for fast per-flow decisions while respecting GA-computed weights.

    Algorithm:
      current_weight_i += weight_i
      pick max current_weight
      current_weight_chosen -= total_weight
    """
    _current: dict = field(default_factory=dict)

    def choose(self, backends: List[Backend]) -> Backend:
        candidates = [b for b in backends if b.enabled and b.ofport is not None]
        if not candidates:
            # If ports are not learned yet, allow enabled backends without ports as candidates.
            candidates = [b for b in backends if b.enabled]
        if not candidates:
            raise ValueError("No enabled backends")

        total = 0
        best = None
        best_cw = None
        for b in candidates:
            w = max(1, int(b.effective_weight()))
            total += w
            cw = self._current.get(b.backend_id, 0) + w
            self._current[b.backend_id] = cw
            if best is None or cw > best_cw:
                best, best_cw = b, cw

        # Smoothness step.
        assert best is not None
        self._current[best.backend_id] = self._current.get(best.backend_id, 0) - total
        return best
