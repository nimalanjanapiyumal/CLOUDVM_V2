from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional


@dataclass(frozen=True)
class BackendInfo:
    backend_id: str
    base_weight: int = 1


class RoundRobin:
    """Simple round robin over a stable backend list."""

    def __init__(self) -> None:
        self._idx = 0

    def choose(self, backend_ids: List[str]) -> Optional[str]:
        if not backend_ids:
            return None
        self._idx = self._idx % len(backend_ids)
        choice = backend_ids[self._idx]
        self._idx = (self._idx + 1) % len(backend_ids)
        return choice


class SmoothWeightedRoundRobin:
    """Smooth Weighted Round Robin (SWRR).

    Weights are integers. Algorithm produces smoother distribution than naive weighted RR.
    """

    def __init__(self) -> None:
        self._current: Dict[str, int] = {}

    def choose(self, weights: Dict[str, int]) -> Optional[str]:
        # weights: backend_id -> weight (>=0)
        alive = {k: int(v) for k, v in weights.items() if int(v) > 0}
        if not alive:
            return None

        # Ensure current state exists for all
        for bid in alive:
            self._current.setdefault(bid, 0)

        total = sum(alive.values())

        # Add weights to current
        for bid, w in alive.items():
            self._current[bid] += w

        # Pick max current
        best = max(alive.keys(), key=lambda bid: self._current.get(bid, 0))

        # Subtract total from best
        self._current[best] -= total
        return best
