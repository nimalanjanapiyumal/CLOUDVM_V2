from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import List, Sequence, Tuple

from hybrid_lb.model import Backend


@dataclass
class GAConfig:
    population: int = 30
    generations: int = 40
    crossover_rate: float = 0.8
    mutation_rate: float = 0.2
    weight_min: int = 1
    weight_max: int = 10
    seed: int = 42


class GeneticOptimizer:
    """A lightweight GA that optimizes backend weights.

    This is intentionally simple so it can run periodically in an SDN controller loop.
    The objective is to keep traffic shares aligned with (capacity / current_load).
    """

    def __init__(self, cfg: GAConfig | None = None) -> None:
        self.cfg = cfg or GAConfig()
        self._rng = random.Random(self.cfg.seed)

    def _desired_shares(self, backends: Sequence[Backend]) -> List[float]:
        # 'Load' is derived from dataplane-observable metrics.
        desires = []
        for b in backends:
            if not b.enabled:
                desires.append(0.0)
                continue
            cap = max(1.0, float(b.base_weight))
            load = float(b.stats.active_flows) + (b.stats.bps_out / 1_000_000.0)  # flows + Mbps
            desires.append(cap / (1.0 + load))

        s = sum(desires)
        if s <= 0:
            # fallback to uniform
            n = max(1, len(backends))
            return [1.0 / n] * n
        return [d / s for d in desires]

    def _fitness(self, weights: Sequence[int], desired: Sequence[float], enabled: Sequence[bool]) -> float:
        # Higher is better.
        total = sum(weights)
        if total <= 0:
            return -1e9
        shares = [w / total for w in weights]
        err = 0.0
        for sh, ds, en, w in zip(shares, desired, enabled, weights):
            if (not en) and (w > 0):
                err += 1.0
            err += (sh - ds) ** 2
        return -err

    def _init_population(self, n: int, m: int) -> List[List[int]]:
        pop = []
        for _ in range(n):
            ind = [self._rng.randint(self.cfg.weight_min, self.cfg.weight_max) for _ in range(m)]
            pop.append(ind)
        return pop

    def _select(self, pop: List[List[int]], fitnesses: List[float]) -> List[int]:
        # Tournament selection
        k = 3
        best = None
        best_fit = None
        for _ in range(k):
            i = self._rng.randrange(len(pop))
            if best is None or fitnesses[i] > best_fit:
                best = pop[i]
                best_fit = fitnesses[i]
        assert best is not None
        return best[:]

    def _crossover(self, a: List[int], b: List[int]) -> Tuple[List[int], List[int]]:
        if len(a) != len(b) or len(a) < 2:
            return a[:], b[:]
        if self._rng.random() > self.cfg.crossover_rate:
            return a[:], b[:]
        p = self._rng.randrange(1, len(a))
        c1 = a[:p] + b[p:]
        c2 = b[:p] + a[p:]
        return c1, c2

    def _mutate(self, ind: List[int]) -> List[int]:
        out = ind[:]
        for i in range(len(out)):
            if self._rng.random() < self.cfg.mutation_rate:
                delta = self._rng.choice([-2, -1, 1, 2])
                out[i] = min(self.cfg.weight_max, max(self.cfg.weight_min, out[i] + delta))
        return out

    def optimize(self, backends: Sequence[Backend]) -> List[int]:
        if not backends:
            return []

        desired = self._desired_shares(backends)
        enabled = [b.enabled for b in backends]

        pop = self._init_population(self.cfg.population, len(backends))
        best_ind = pop[0]
        best_fit = -1e18

        for _gen in range(self.cfg.generations):
            fits = [self._fitness(ind, desired, enabled) for ind in pop]
            # Track best.
            for ind, f in zip(pop, fits):
                if f > best_fit:
                    best_fit = f
                    best_ind = ind[:]

            # Create next generation.
            new_pop = []
            while len(new_pop) < len(pop):
                p1 = self._select(pop, fits)
                p2 = self._select(pop, fits)
                c1, c2 = self._crossover(p1, p2)
                c1 = self._mutate(c1)
                c2 = self._mutate(c2)
                new_pop.extend([c1, c2])
            pop = new_pop[: len(pop)]

        # Ensure weights are valid ints.
        out = [min(self.cfg.weight_max, max(self.cfg.weight_min, int(w))) for w in best_ind]
        return out
