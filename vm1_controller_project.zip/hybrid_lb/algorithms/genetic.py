from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Dict, List, Tuple


@dataclass
class GAConfig:
    population: int = 18
    generations: int = 20
    mutation_rate: float = 0.15
    elite_ratio: float = 0.2
    target_mbps: float = 20.0


def _normalize_int_weights(raw: List[float], min_w: int = 1, max_w: int = 10) -> List[int]:
    # Convert arbitrary floats to bounded integer weights.
    if not raw:
        return []
    mn = min(raw)
    mx = max(raw)
    if mx - mn < 1e-9:
        return [min_w for _ in raw]
    scaled = [(x - mn) / (mx - mn) for x in raw]  # 0..1
    weights = [int(round(min_w + s * (max_w - min_w))) for s in scaled]
    return [max(min_w, min(max_w, w)) for w in weights]


def _fitness(candidate: List[int], loads_mbps: List[float], target_mbps: float) -> float:
    """Higher is better.
    We want higher weight for lower load; penalize assigning weight to overloaded backends.
    """
    if not candidate or len(candidate) != len(loads_mbps):
        return -1e9
    total_w = sum(candidate)
    if total_w <= 0:
        return -1e9

    # Ideal share per backend proportional to weight.
    # Penalize deviation from "give more to less loaded" and from target.
    score = 0.0
    for w, load in zip(candidate, loads_mbps):
        # If load is above target, prefer lower weight.
        # If below target, prefer higher weight.
        # Use a smooth utility.
        delta = (target_mbps - load)
        score += (w / total_w) * delta

        # Strong penalty if load is extremely high
        if load > target_mbps * 3:
            score -= (load - target_mbps * 3) * 0.5

    # Encourage some diversity (avoid all equal in heterogeneous load)
    score += 0.05 * (max(candidate) - min(candidate))
    return score


def _crossover(a: List[int], b: List[int]) -> Tuple[List[int], List[int]]:
    if len(a) != len(b) or not a:
        return a[:], b[:]
    cut = random.randint(1, len(a) - 1)
    return a[:cut] + b[cut:], b[:cut] + a[cut:]


def _mutate(x: List[int], mutation_rate: float, min_w: int = 1, max_w: int = 10) -> List[int]:
    out = x[:]
    for i in range(len(out)):
        if random.random() < mutation_rate:
            step = random.choice([-2, -1, 1, 2])
            out[i] = max(min_w, min(max_w, out[i] + step))
    return out


class GeneticOptimizer:
    """GA optimizer that outputs integer weights per backend.

    Inputs are the current measured loads (e.g., Mbps tx/rx) and backend IDs.
    """

    def __init__(self, cfg: GAConfig) -> None:
        self.cfg = cfg

    def optimize(self, backend_ids: List[str], loads_mbps: List[float]) -> Dict[str, int]:
        if not backend_ids:
            return {}
        n = len(backend_ids)
        if len(loads_mbps) != n:
            loads_mbps = loads_mbps[:n] + [0.0] * max(0, n - len(loads_mbps))

        # Seed: inverse-load heuristic (lower load => higher initial weight)
        seed_raw = [1.0 / max(0.1, l) for l in loads_mbps]
        seed = _normalize_int_weights(seed_raw)

        pop: List[List[int]] = []
        pop.append(seed)
        while len(pop) < self.cfg.population:
            cand = [random.randint(1, 10) for _ in range(n)]
            pop.append(cand)

        elite_n = max(1, int(round(self.cfg.elite_ratio * self.cfg.population)))

        best = seed
        best_fit = _fitness(best, loads_mbps, self.cfg.target_mbps)

        for _gen in range(self.cfg.generations):
            scored = sorted(
                ((cand, _fitness(cand, loads_mbps, self.cfg.target_mbps)) for cand in pop),
                key=lambda t: t[1],
                reverse=True,
            )
            elites = [cand for cand, _f in scored[:elite_n]]

            if scored and scored[0][1] > best_fit:
                best, best_fit = scored[0]

            # Reproduce
            new_pop: List[List[int]] = elites[:]
            while len(new_pop) < self.cfg.population:
                p1 = random.choice(elites)
                p2 = random.choice(elites)
                c1, c2 = _crossover(p1, p2)
                new_pop.append(_mutate(c1, self.cfg.mutation_rate))
                if len(new_pop) < self.cfg.population:
                    new_pop.append(_mutate(c2, self.cfg.mutation_rate))
            pop = new_pop

        return {bid: int(w) for bid, w in zip(backend_ids, best)}
