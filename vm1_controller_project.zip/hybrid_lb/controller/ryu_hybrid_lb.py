from __future__ import annotations

import os
import time
import logging
from typing import Dict, Optional, Tuple

from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER, CONFIG_DISPATCHER, set_ev_cls
from ryu.lib.packet import packet
from ryu.lib.packet import ethernet, arp, ipv4, tcp, udp
from ryu.lib import hub
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import ether_types

from prometheus_client import start_http_server

from ..config import load_config
from ..model import BackendLiveState
from ..utils.logging import setup_logging
from ..algorithms.hybrid import HybridLoadBalancer, GatingThresholds
from ..algorithms.genetic import GAConfig
from ..monitoring.metrics import create_metrics
from .flow_manager import add_flow, send_packet_out


LOG = logging.getLogger("hybrid_lb.ryu")


class HybridLoadBalancerRyu(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        cfg_path = os.environ.get("HYBRID_LB_CONFIG", os.path.join(os.path.dirname(__file__), "..", "..", "config", "default.yaml"))
        cfg_path = os.path.abspath(cfg_path)
        self.cfg = load_config(cfg_path)

        setup_logging(self.cfg.log_level)
        LOG.info("Loaded config from %s", cfg_path)

        self.vip_ip = self.cfg.vip.ip
        self.vip_mac = self.cfg.vip.mac.lower()
        self.vip_tcp_port = int(self.cfg.vip.tcp_port)

        # backend config
        self.backends = self.cfg.backends
        self.backend_ids = [b.backend_id for b in self.backends]
        self.base_weights = {b.backend_id: int(b.base_weight) for b in self.backends}
        self.backend_by_ip = {b.ip: b for b in self.backends}
        self.backend_by_id = {b.backend_id: b for b in self.backends}

        ga_cfg = GAConfig(
            population=self.cfg.algorithms.ga.population,
            generations=self.cfg.algorithms.ga.generations,
            mutation_rate=self.cfg.algorithms.ga.mutation_rate,
            elite_ratio=self.cfg.algorithms.ga.elite_ratio,
            target_mbps=self.cfg.algorithms.ga.target_mbps,
        )
        gating = GatingThresholds(
            max_mbps_tx=self.cfg.gating.max_mbps_tx,
            max_mbps_rx=self.cfg.gating.max_mbps_rx,
            max_active_flows=self.cfg.gating.max_active_flows,
        )
        self.lb = HybridLoadBalancer(
            rr_mode=self.cfg.algorithms.rr.mode,
            ga_enabled=self.cfg.algorithms.ga.enabled,
            ga_cfg=ga_cfg,
            gating=gating,
        )

        # OpenFlow state
        self.datapath = None
        self.mac_to_port: Dict[int, Dict[str, int]] = {}
        self.backend_state: Dict[str, BackendLiveState] = {bid: BackendLiveState() for bid in self.backend_ids}

        # Port stats tracking
        self._port_bytes_prev: Dict[Tuple[int, int], Tuple[int, int, float]] = {}  # (dpid, port)-> (tx_bytes, rx_bytes, ts)

        # Prometheus
        self.metrics = create_metrics()
        try:
            start_http_server(int(self.cfg.controller.metrics_port))
            LOG.info("Prometheus metrics listening on :%d", int(self.cfg.controller.metrics_port))
        except Exception as e:
            LOG.warning("Could not start metrics HTTP server: %s", e)

        # Start monitor threads
        self._monitor_thread = hub.spawn(self._monitor)
        self._ga_thread = hub.spawn(self._ga_loop)

    # ---------- Switch setup ----------
    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        datapath = ev.msg.datapath
        self.datapath = datapath
        dpid = datapath.id
        self.mac_to_port.setdefault(dpid, {})

        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        # table-miss: send to controller
        match = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER, ofproto.OFPCML_NO_BUFFER)]
        add_flow(datapath, 0, match, actions, idle_timeout=0)

        LOG.info("Switch connected (dpid=%s). Installed table-miss.", dpid)

    # ---------- PacketIn ----------
    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def packet_in_handler(self, ev):
        msg = ev.msg
        datapath = msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        in_port = msg.match["in_port"]
        dpid = datapath.id
        self.mac_to_port.setdefault(dpid, {})

        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocol(ethernet.ethernet)
        if eth is None:
            return

        # Ignore LLDP
        if eth.ethertype == ether_types.ETH_TYPE_LLDP:
            return

        src = eth.src.lower()
        dst = eth.dst.lower()

        # Learn MAC
        self.mac_to_port[dpid][src] = in_port

        # Handle ARP
        arp_pkt = pkt.get_protocol(arp.arp)
        if arp_pkt:
            if arp_pkt.opcode == arp.ARP_REQUEST and arp_pkt.dst_ip == self.vip_ip:
                self._reply_arp(datapath, in_port, src_mac=src, src_ip=arp_pkt.src_ip)
                return

            # Normal L2 switching for ARP
            out_port = self.mac_to_port[dpid].get(dst, ofproto.OFPP_FLOOD)
            actions = [parser.OFPActionOutput(out_port)]
            send_packet_out(datapath, in_port, actions, msg.data)
            return

        ip_pkt = pkt.get_protocol(ipv4.ipv4)
        if ip_pkt:
            # VIP traffic?
            if ip_pkt.dst == self.vip_ip:
                self._handle_vip_ipv4(msg, pkt, eth, ip_pkt, in_port)
                return

        # Default L2 switching
        out_port = self.mac_to_port[dpid].get(dst, ofproto.OFPP_FLOOD)
        actions = [parser.OFPActionOutput(out_port)]
        send_packet_out(datapath, in_port, actions, msg.data)

    def _reply_arp(self, datapath, in_port: int, *, src_mac: str, src_ip: str) -> None:
        """Respond to ARP request for the VIP."""
        parser = datapath.ofproto_parser
        ofproto = datapath.ofproto

        e = ethernet.ethernet(dst=src_mac, src=self.vip_mac, ethertype=ether_types.ETH_TYPE_ARP)
        a = arp.arp(
            opcode=arp.ARP_REPLY,
            src_mac=self.vip_mac,
            src_ip=self.vip_ip,
            dst_mac=src_mac,
            dst_ip=src_ip,
        )
        p = packet.Packet()
        p.add_protocol(e)
        p.add_protocol(a)
        p.serialize()

        actions = [parser.OFPActionOutput(in_port)]
        send_packet_out(datapath, ofproto.OFPP_CONTROLLER, actions, p.data)
        LOG.debug("Replied ARP for VIP %s -> %s", self.vip_ip, src_mac)

    def _handle_vip_ipv4(self, msg, pkt, eth, ip_pkt, in_port: int) -> None:
        datapath = msg.datapath
        dpid = datapath.id
        parser = datapath.ofproto_parser
        ofproto = datapath.ofproto

        client_ip = ip_pkt.src
        client_mac = eth.src.lower()

        # Determine transport ports if present (for more specific flows)
        ip_proto = ip_pkt.proto
        tp_src = None
        tp_dst = None
        tcp_pkt = pkt.get_protocol(tcp.tcp)
        udp_pkt = pkt.get_protocol(udp.udp)
        if tcp_pkt:
            tp_src, tp_dst = tcp_pkt.src_port, tcp_pkt.dst_port
        elif udp_pkt:
            tp_src, tp_dst = udp_pkt.src_port, udp_pkt.dst_port

        live = {bid: self.backend_state[bid].as_tuple() for bid in self.backend_ids}
        chosen = self.lb.choose_backend(self.backend_ids, base_weights=self.base_weights, live_load=live)

        if not chosen:
            LOG.warning("No backend available; flooding VIP packet")
            actions = [parser.OFPActionOutput(ofproto.OFPP_FLOOD)]
            send_packet_out(datapath, in_port, actions, msg.data)
            return

        b = self.backend_by_id[chosen]
        backend_port = int(b.port) if int(b.port) > 0 else self.mac_to_port[dpid].get(b.mac.lower())
        if not backend_port:
            # fallback: try learned port from backend MAC
            backend_port = self.mac_to_port[dpid].get(b.mac.lower())
        if not backend_port:
            # last resort: flood (will likely reach backend)
            LOG.warning("Backend port unknown for %s; flooding once (learn ports by pingAll)", chosen)
            actions = [parser.OFPActionOutput(ofproto.OFPP_FLOOD)]
            send_packet_out(datapath, in_port, actions, msg.data)
            return

        # Prepare matches
        # Forward: client -> VIP
        match_kwargs = dict(
            in_port=in_port,
            eth_type=ether_types.ETH_TYPE_IP,
            ipv4_src=client_ip,
            ipv4_dst=self.vip_ip,
            ip_proto=ip_proto,
        )
        if tcp_pkt:
            match_kwargs.update(tcp_src=tp_src, tcp_dst=tp_dst)
        elif udp_pkt:
            match_kwargs.update(udp_src=tp_src, udp_dst=tp_dst)
        fwd_match = parser.OFPMatch(**match_kwargs)

        fwd_actions = [
            parser.OFPActionSetField(eth_src=self.vip_mac),
            parser.OFPActionSetField(eth_dst=b.mac.lower()),
            parser.OFPActionSetField(ipv4_dst=b.ip),
            parser.OFPActionOutput(backend_port),
        ]
        add_flow(datapath, 200, fwd_match, fwd_actions, idle_timeout=30)

        # Reverse: backend -> client
        rev_match_kwargs = dict(
            eth_type=ether_types.ETH_TYPE_IP,
            ipv4_src=b.ip,
            ipv4_dst=client_ip,
            ip_proto=ip_proto,
        )
        if tcp_pkt:
            rev_match_kwargs.update(tcp_src=tp_dst, tcp_dst=tp_src)
        elif udp_pkt:
            rev_match_kwargs.update(udp_src=tp_dst, udp_dst=tp_src)
        rev_match = parser.OFPMatch(**rev_match_kwargs)

        client_port = self.mac_to_port[dpid].get(client_mac, in_port)
        rev_actions = [
            parser.OFPActionSetField(eth_src=self.vip_mac),
            parser.OFPActionSetField(eth_dst=client_mac),
            parser.OFPActionSetField(ipv4_src=self.vip_ip),
            parser.OFPActionOutput(client_port),
        ]
        add_flow(datapath, 200, rev_match, rev_actions, idle_timeout=30)

        # Update active flow counters (approx)
        st = self.backend_state[chosen]
        st.active_flows += 1
        self.backend_state[chosen] = st

        # Update metrics
        self.metrics.backend_weight.labels(chosen).set(self.lb.weights.get(chosen, 1))
        self.metrics.backend_active_flows.labels(chosen).set(st.active_flows)

        # Send packet out immediately using same actions
        send_packet_out(datapath, in_port, fwd_actions, msg.data)
        LOG.info("VIP flow %s:%s -> %s:%s assigned to %s", client_ip, tp_src, self.vip_ip, tp_dst, chosen)

    # ---------- Monitoring ----------
    def _monitor(self):
        while True:
            try:
                if self.datapath is not None:
                    self._request_port_stats(self.datapath)
            except Exception as e:
                LOG.debug("monitor exception: %s", e)
            hub.sleep(2.0)

    def _request_port_stats(self, datapath):
        parser = datapath.ofproto_parser
        req = parser.OFPPortStatsRequest(datapath, 0, datapath.ofproto.OFPP_ANY)
        datapath.send_msg(req)

    @set_ev_cls(ofp_event.EventOFPPortStatsReply, MAIN_DISPATCHER)
    def _port_stats_reply_handler(self, ev):
        msg = ev.msg
        dp = msg.datapath
        dpid = dp.id
        now = time.time()

        # Map port -> backend_id (based on config)
        port_to_backend = {int(b.port): b.backend_id for b in self.backends if int(b.port) > 0}

        for stat in msg.body:
            port_no = int(stat.port_no)
            if port_no not in port_to_backend:
                continue

            bid = port_to_backend[port_no]
            tx_bytes = int(stat.tx_bytes)
            rx_bytes = int(stat.rx_bytes)

            key = (dpid, port_no)
            prev = self._port_bytes_prev.get(key)
            if prev:
                prev_tx, prev_rx, prev_ts = prev
                dt = max(0.5, now - prev_ts)
                mbps_tx = ((tx_bytes - prev_tx) * 8.0) / (dt * 1_000_000)
                mbps_rx = ((rx_bytes - prev_rx) * 8.0) / (dt * 1_000_000)

                st = self.backend_state.get(bid, BackendLiveState())
                st.mbps_tx = max(0.0, mbps_tx)
                st.mbps_rx = max(0.0, mbps_rx)
                # active flows: decay slowly to avoid monotonic growth
                st.active_flows = max(0, int(st.active_flows * 0.95))
                self.backend_state[bid] = st

                self.metrics.backend_mbps_tx.labels(bid).set(st.mbps_tx)
                self.metrics.backend_mbps_rx.labels(bid).set(st.mbps_rx)
                self.metrics.backend_active_flows.labels(bid).set(st.active_flows)

            self._port_bytes_prev[key] = (tx_bytes, rx_bytes, now)

    # ---------- GA loop ----------
    def _ga_loop(self):
        interval = max(5, int(self.cfg.algorithms.ga.interval_sec))
        while True:
            try:
                if self.cfg.algorithms.ga.enabled:
                    t0 = time.time()
                    loads = []
                    for bid in self.backend_ids:
                        st = self.backend_state.get(bid, BackendLiveState())
                        # combine tx+rx as a single load proxy
                        loads.append(float(st.mbps_tx + st.mbps_rx))
                    new_weights = self.lb.ga_optimize(self.backend_ids, loads)
                    if new_weights:
                        self.lb.set_weights(new_weights)
                        for bid, w in new_weights.items():
                            self.metrics.backend_weight.labels(bid).set(w)
                    dt = time.time() - t0
                    self.metrics.ga_last_runtime_seconds.set(dt)
                    self.metrics.ga_last_run_timestamp.set(time.time())
                    LOG.info("GA updated weights: %s (%.3fs)", new_weights, dt)
            except Exception as e:
                LOG.warning("GA loop error: %s", e)
            hub.sleep(interval)
