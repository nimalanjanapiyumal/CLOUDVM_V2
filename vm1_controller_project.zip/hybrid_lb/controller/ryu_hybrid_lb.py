from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from os_ken.base import app_manager
from os_ken.controller import ofp_event
from os_ken.controller.handler import CONFIG_DISPATCHER, MAIN_DISPATCHER, set_ev_cls
from os_ken.lib import hub
from os_ken.lib.packet import arp, ethernet, ipv4, packet, tcp, udp
from os_ken.ofproto import ether, ether_types, ofproto_v1_3
from os_ken.app.wsgi import WSGIApplication

from hybrid_lb.algorithms.genetic import GeneticOptimizer
from hybrid_lb.algorithms.hybrid import HybridLoadBalancer
from hybrid_lb.config import AppConfig, load_config
from hybrid_lb.controller.flow_manager import add_flow, add_table_miss_flow
from hybrid_lb.model import Backend
from hybrid_lb.monitoring.metrics import (
    LB_DECISIONS_TOTAL,
    SWITCH_CONNECTED,
    mark_ga_run,
    start_metrics_server,
    update_backend_metrics,
)
from hybrid_lb.rest.api import HybridLBRestController
from hybrid_lb.utils.logging import setup_logging

LOG = logging.getLogger("hybrid_lb.osken")


class HybridSDNLoadBalancer(app_manager.OSKenApp):
    """Hybrid RR+GA SDN load balancer (OpenFlow 1.3) with a VIP.

    Proposal alignment:
      - Client → (VIP/API Gateway) → SDN Controller (Hybrid RR + GA) → Flow rule updates → Data plane switch
      - Monitoring + updates loop
      - Tested on Mininet + OS-Ken (Ryu fork); deployable in OpenStack VMs (controller VM + dataplane VM)

    Implementation summary:
      - VIP is handled via ARP reply (virtual MAC).
      - New TCP/UDP flows to the VIP are rewritten to a selected backend (fast SWRR, weights updated by GA).
      - Port stats are polled for bandwidth estimates.
      - A REST API exposes status + config (northbound).
    """

    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]
    _CONTEXTS = {"wsgi": WSGIApplication}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        setup_logging("controller", log_dir=os.environ.get("HYBRID_LB_LOG_DIR", "./logs"))

        cfg_path = os.environ.get("HYBRID_LB_CONFIG", "./config/default.yaml")
        self.cfg: AppConfig = load_config(cfg_path)

        self.vip_ip = self.cfg.vip.ip
        self.vip_mac = self.cfg.vip.mac
        self.service_ports = set(self.cfg.services)

        self.backends: List[Backend] = self.cfg.backends
        self.backend_by_ip: Dict[str, Backend] = {b.ip: b for b in self.backends}

        # Learning switch tables.
        self.mac_to_port: Dict[int, Dict[str, int]] = {}  # dpid -> mac -> port

        # Flow stickiness: (src_ip, src_port, proto, vip_port) -> backend_id
        self.flow_map: Dict[Tuple[str, int, int, int], str] = {}
        self.flow_last_seen: Dict[Tuple[str, int, int, int], float] = {}

        self.datapaths: Dict[int, object] = {}

        self.hybrid = HybridLoadBalancer(self.cfg.thresholds)
        self.ga = GeneticOptimizer(self.cfg.ga)

        # Monitoring loops.
        self._stats_poll_interval = max(1, int(self.cfg.monitoring.stats_poll_seconds))
        self._state_dump_interval = max(1, int(self.cfg.monitoring.state_dump_seconds))
        self._ga_interval = max(5, int(self.cfg.ga_interval_seconds))
        self._ga_enabled = bool(self.cfg.ga_enabled)

        hub.spawn(self._monitor_loop)
        hub.spawn(self._ga_loop)
        hub.spawn(self._state_dump_loop)

        # Start Prometheus metrics server.
        start_metrics_server(self.cfg.controller.metrics_port)

        # REST API (northbound).
        wsgi = kwargs["wsgi"]
        wsgi.register(HybridLBRestController, {"app": self})

        LOG.info("HybridSDNLoadBalancer ready (VIP=%s, services=%s)", self.vip_ip, sorted(self.service_ports))

    # ---------------- REST helpers ----------------

    def discovery_payload(self) -> dict:
        return {
            "vip": {"ip": self.vip_ip, "mac": self.vip_mac, "services": sorted(self.service_ports)},
            "controller": {
                "of_listen_port": self.cfg.controller.of_listen_port,
                "rest_port": self.cfg.controller.rest_port,
                "metrics_port": self.cfg.controller.metrics_port,
            },
        }

    def thresholds_payload(self) -> dict:
        return {
            "max_active_flows": self.hybrid.thresholds.max_active_flows,
            "max_mbps_out": self.hybrid.thresholds.max_mbps_out,
        }

    def ga_payload(self) -> dict:
        return {"enabled": self._ga_enabled, "interval_seconds": self._ga_interval, "last_run_ts": self.hybrid.last_ga_ts}

    def status_payload(self) -> dict:
        return {
            "vip": {"ip": self.vip_ip, "mac": self.vip_mac, "services": sorted(self.service_ports)},
            "thresholds": self.thresholds_payload(),
            "ga": self.ga_payload(),
            "backends": [b.to_dict() for b in self.backends],
            "flows": {"active": len(self.flow_map)},
            "switches": {"connected": len(self.datapaths)},
        }

    def set_thresholds(self, max_active_flows, max_mbps_out) -> None:
        self.hybrid.update_thresholds(max_active_flows, max_mbps_out)
        LOG.info("Updated thresholds: %s", self.thresholds_payload())

    def set_ga(self, enabled, interval_seconds) -> None:
        if enabled is not None:
            self._ga_enabled = bool(enabled)
        if interval_seconds is not None:
            self._ga_interval = max(5, int(interval_seconds))
        LOG.info("Updated GA config: %s", self.ga_payload())

    # ---------------- Ryu events ----------------

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        datapath = ev.msg.datapath
        dpid = datapath.id
        self.datapaths[dpid] = datapath
        self.mac_to_port.setdefault(dpid, {})

        add_table_miss_flow(datapath)
        SWITCH_CONNECTED.set(1)

        LOG.info("Switch connected: dpid=%s", dpid)

    @set_ev_cls(ofp_event.EventOFPStateChange, MAIN_DISPATCHER)
    def _state_change_handler(self, ev):
        dp = ev.datapath
        if dp is None:
            return
        self.datapaths[dp.id] = dp
        SWITCH_CONNECTED.set(1 if self.datapaths else 0)

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def packet_in_handler(self, ev):
        msg = ev.msg
        datapath = msg.datapath
        dpid = datapath.id
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        in_port = msg.match["in_port"]

        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocol(ethernet.ethernet)
        if eth is None:
            return

        src_mac = eth.src
        dst_mac = eth.dst

        # L2 learning
        self.mac_to_port.setdefault(dpid, {})
        self.mac_to_port[dpid][src_mac] = in_port

        # ARP
        arp_pkt = pkt.get_protocol(arp.arp)
        if arp_pkt:
            # Learn backend L2 mapping from ARP src_ip.
            if arp_pkt.src_ip in self.backend_by_ip:
                b = self.backend_by_ip[arp_pkt.src_ip]
                b.mac = src_mac
                b.ofport = in_port

            # Reply to VIP ARP.
            if arp_pkt.opcode == arp.ARP_REQUEST and arp_pkt.dst_ip == self.vip_ip:
                self._send_arp_reply_for_vip(datapath, in_port, requester_mac=src_mac, requester_ip=arp_pkt.src_ip)
                return

            # Else L2 switch behavior for ARP.
            self._fwd_learning_switch(datapath, in_port, dst_mac, msg.buffer_id, msg.data)
            return

        # IPv4
        ip_pkt = pkt.get_protocol(ipv4.ipv4)
        if ip_pkt:
            # Learn backend L2 mapping from IPv4 src.
            if ip_pkt.src in self.backend_by_ip:
                b = self.backend_by_ip[ip_pkt.src]
                b.mac = src_mac
                b.ofport = in_port

            self._handle_ipv4(datapath, in_port, pkt, eth, ip_pkt, msg.buffer_id)
            return

        # Other ethertypes: simple L2 switching
        self._fwd_learning_switch(datapath, in_port, dst_mac, msg.buffer_id, msg.data)

    def _fwd_learning_switch(self, datapath, in_port: int, dst_mac: str, buffer_id: int, data: bytes) -> None:
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        dpid = datapath.id

        out_port = self.mac_to_port.get(dpid, {}).get(dst_mac, ofproto.OFPP_FLOOD)
        actions = [parser.OFPActionOutput(out_port)]
        out = parser.OFPPacketOut(
            datapath=datapath,
            buffer_id=buffer_id,
            in_port=in_port,
            actions=actions,
            data=None if buffer_id != ofproto.OFP_NO_BUFFER else data,
        )
        datapath.send_msg(out)

    def _send_arp_reply_for_vip(self, datapath, in_port: int, requester_mac: str, requester_ip: str) -> None:
        parser = datapath.ofproto_parser
        ofproto = datapath.ofproto

        e = ethernet.ethernet(dst=requester_mac, src=self.vip_mac, ethertype=ether.ETH_TYPE_ARP)
        a = arp.arp(
            opcode=arp.ARP_REPLY,
            src_mac=self.vip_mac,
            src_ip=self.vip_ip,
            dst_mac=requester_mac,
            dst_ip=requester_ip,
        )
        p = packet.Packet()
        p.add_protocol(e)
        p.add_protocol(a)
        p.serialize()

        actions = [parser.OFPActionOutput(in_port)]
        out = parser.OFPPacketOut(
            datapath=datapath,
            buffer_id=ofproto.OFP_NO_BUFFER,
            in_port=ofproto.OFPP_CONTROLLER,
            actions=actions,
            data=p.data,
        )
        datapath.send_msg(out)

    def _handle_ipv4(self, datapath, in_port: int, pkt: packet.Packet, eth, ip_pkt: ipv4.ipv4, buffer_id: int) -> None:
        l4_proto = ip_pkt.proto
        tcp_pkt = pkt.get_protocol(tcp.tcp) if l4_proto == 6 else None
        udp_pkt = pkt.get_protocol(udp.udp) if l4_proto == 17 else None

        if ip_pkt.dst == self.vip_ip and (tcp_pkt or udp_pkt):
            src_port = tcp_pkt.src_port if tcp_pkt else udp_pkt.src_port
            dst_port = tcp_pkt.dst_port if tcp_pkt else udp_pkt.dst_port

            if dst_port in self.service_ports:
                self._handle_vip_flow(datapath, in_port, eth, ip_pkt, l4_proto, src_port, dst_port, buffer_id, pkt)
                return

        # Non-VIP traffic: L2 switching
        self._fwd_learning_switch(datapath, in_port, eth.dst, buffer_id, pkt.data)

    def _handle_vip_flow(
        self,
        datapath,
        in_port: int,
        eth,
        ip_pkt: ipv4.ipv4,
        l4_proto: int,
        src_port: int,
        vip_port: int,
        buffer_id: int,
        pkt: packet.Packet,
    ) -> None:
        parser = datapath.ofproto_parser
        ofproto = datapath.ofproto

        key = (ip_pkt.src, int(src_port), int(l4_proto), int(vip_port))
        self.flow_last_seen[key] = time.time()

        # Sticky mapping if already exists.
        backend_id = self.flow_map.get(key)
        backend = None
        if backend_id:
            backend = next((b for b in self.backends if b.backend_id == backend_id and b.enabled), None)

        if backend is None:
            backend = self.hybrid.choose_backend(self.backends)
            self.flow_map[key] = backend.backend_id
            backend.stats.active_flows += 1

        # Prometheus metric.
        LB_DECISIONS_TOTAL.labels(backend.backend_id, str(vip_port)).inc()

        # Require L2 learning to have happened.
        if backend.mac is None or backend.ofport is None:
            LOG.warning("Backend %s missing mac/ofport; run dataplane pingAll first.", backend.backend_id)
            return

        client_mac = eth.src

        # Forward flow: client -> VIP:vip_port => backend
        match_fwd_kwargs = dict(
            in_port=in_port,
            eth_type=ether_types.ETH_TYPE_IP,
            ip_proto=l4_proto,
            ipv4_src=ip_pkt.src,
            ipv4_dst=self.vip_ip,
        )
        if l4_proto == 6:
            match_fwd_kwargs.update(tcp_src=src_port, tcp_dst=vip_port)
        else:
            match_fwd_kwargs.update(udp_src=src_port, udp_dst=vip_port)

        match_fwd = parser.OFPMatch(**match_fwd_kwargs)
        actions_fwd = [
            parser.OFPActionSetField(eth_dst=backend.mac),
            parser.OFPActionSetField(eth_src=self.vip_mac),
            parser.OFPActionSetField(ipv4_dst=backend.ip),
            parser.OFPActionOutput(backend.ofport),
        ]
        add_flow(datapath, priority=100, match=match_fwd, actions=actions_fwd, idle_timeout=60)

        # Reverse flow: backend -> client
        match_rev_kwargs = dict(
            in_port=backend.ofport,
            eth_type=ether_types.ETH_TYPE_IP,
            ip_proto=l4_proto,
            ipv4_src=backend.ip,
            ipv4_dst=ip_pkt.src,
        )
        if l4_proto == 6:
            match_rev_kwargs.update(tcp_src=vip_port, tcp_dst=src_port)
        else:
            match_rev_kwargs.update(udp_src=vip_port, udp_dst=src_port)

        match_rev = parser.OFPMatch(**match_rev_kwargs)
        actions_rev = [
            parser.OFPActionSetField(eth_dst=client_mac),
            parser.OFPActionSetField(eth_src=self.vip_mac),
            parser.OFPActionSetField(ipv4_src=self.vip_ip),
            parser.OFPActionOutput(in_port),
        ]
        add_flow(datapath, priority=100, match=match_rev, actions=actions_rev, idle_timeout=60)

        # PacketOut for the first packet.
        out = parser.OFPPacketOut(
            datapath=datapath,
            buffer_id=buffer_id,
            in_port=in_port,
            actions=actions_fwd,
            data=None if buffer_id != ofproto.OFP_NO_BUFFER else pkt.data,
        )
        datapath.send_msg(out)

    # ---------------- Monitoring loops ----------------

    def _monitor_loop(self):
        while True:
            for _dpid, dp in list(self.datapaths.items()):
                try:
                    parser = dp.ofproto_parser
                    req = parser.OFPPortStatsRequest(dp, 0, dp.ofproto.OFPP_ANY)
                    dp.send_msg(req)
                except Exception as e:
                    LOG.warning("PortStatsRequest failed: %s", e)
            hub.sleep(self._stats_poll_interval)

    @set_ev_cls(ofp_event.EventOFPPortStatsReply, MAIN_DISPATCHER)
    def _port_stats_reply_handler(self, ev):
        now = time.time()
        port_stats = {s.port_no: s for s in ev.msg.body}

        for b in self.backends:
            if b.ofport is None:
                continue
            s = port_stats.get(b.ofport)
            if s is None:
                continue

            last_rx = b.stats.extra.get("rx_bytes", float(s.rx_bytes))
            last_tx = b.stats.extra.get("tx_bytes", float(s.tx_bytes))
            last_ts = b.stats.extra.get("ts", now)
            dt = max(0.001, now - last_ts)

            b.stats.bps_in = max(0.0, (float(s.rx_bytes) - last_rx) * 8.0 / dt)
            b.stats.bps_out = max(0.0, (float(s.tx_bytes) - last_tx) * 8.0 / dt)
            b.stats.last_seen_ts = now

            b.stats.extra["rx_bytes"] = float(s.rx_bytes)
            b.stats.extra["tx_bytes"] = float(s.tx_bytes)
            b.stats.extra["ts"] = now

        update_backend_metrics(self.backends)

    def _ga_loop(self):
        while True:
            if self._ga_enabled:
                try:
                    weights = self.ga.optimize(self.backends)
                    if weights:
                        self.hybrid.apply_ga_weights(self.backends, weights)
                        mark_ga_run(self.hybrid.last_ga_ts)
                        update_backend_metrics(self.backends)
                        LOG.info("GA weights updated: %s", {b.backend_id: b.ga_weight for b in self.backends})
                except Exception as e:
                    LOG.exception("GA loop error: %s", e)
            hub.sleep(self._ga_interval)

    def _state_dump_loop(self):
        state_path = Path(self.cfg.monitoring.state_path)
        state_path.parent.mkdir(parents=True, exist_ok=True)

        while True:
            try:
                now = time.time()
                # Cleanup stale flow mappings.
                stale = [k for k, ts in self.flow_last_seen.items() if now - ts > 65]
                for k in stale:
                    backend_id = self.flow_map.pop(k, None)
                    self.flow_last_seen.pop(k, None)
                    if backend_id:
                        b = next((x for x in self.backends if x.backend_id == backend_id), None)
                        if b and b.stats.active_flows > 0:
                            b.stats.active_flows -= 1

                state_path.write_text(json.dumps(self.status_payload(), indent=2), encoding="utf-8")
            except Exception as e:
                LOG.warning("State dump failed: %s", e)
            hub.sleep(self._state_dump_interval)
