from __future__ import annotations

from typing import List, Optional

from ryu.ofproto import ofproto_v1_3
from ryu.ofproto import ether
from ryu.lib.packet import ether_types


def add_flow(datapath, priority: int, match, actions, idle_timeout: int = 60, hard_timeout: int = 0) -> None:
    """Install a flow into the datapath."""
    ofproto = datapath.ofproto
    parser = datapath.ofproto_parser

    inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
    mod = parser.OFPFlowMod(
        datapath=datapath,
        priority=priority,
        match=match,
        instructions=inst,
        idle_timeout=idle_timeout,
        hard_timeout=hard_timeout,
    )
    datapath.send_msg(mod)


def add_table_miss_flow(datapath, priority: int = 0) -> None:
    """Send unmatched packets to controller."""
    ofproto = datapath.ofproto
    parser = datapath.ofproto_parser
    match = parser.OFPMatch()
    actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER, ofproto.OFPCML_NO_BUFFER)]
    add_flow(datapath, priority, match, actions, idle_timeout=0, hard_timeout=0)
