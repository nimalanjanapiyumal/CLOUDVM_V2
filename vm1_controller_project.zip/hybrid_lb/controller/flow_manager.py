from __future__ import annotations

from typing import List, Optional

from ryu.ofproto import ofproto_v1_3


def add_flow(datapath, priority: int, match, actions: List, idle_timeout: int = 30, hard_timeout: int = 0) -> None:
    ofproto = datapath.ofproto
    parser = datapath.ofproto_parser
    inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
    mod = parser.OFPFlowMod(
        datapath=datapath,
        priority=priority,
        match=match,
        instructions=inst,
        idle_timeout=idle_timeout,
        hard_timeout=hard_timeout,
    )
    datapath.send_msg(mod)


def send_packet_out(datapath, in_port: int, actions: List, data: bytes) -> None:
    parser = datapath.ofproto_parser
    out = parser.OFPPacketOut(
        datapath=datapath,
        buffer_id=datapath.ofproto.OFP_NO_BUFFER,
        in_port=in_port,
        actions=actions,
        data=data,
    )
    datapath.send_msg(out)
