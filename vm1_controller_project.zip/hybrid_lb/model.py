from __future__ import annotations

from dataclasses import dataclass
from typing import Dict


@dataclass
class BackendLiveState:
    mbps_tx: float = 0.0
    mbps_rx: float = 0.0
    active_flows: int = 0

    def as_tuple(self):
        return (self.mbps_tx, self.mbps_rx, self.active_flows)
