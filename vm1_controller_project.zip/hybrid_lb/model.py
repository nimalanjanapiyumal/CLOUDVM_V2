from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional


@dataclass
class BackendStats:
    """Runtime stats we track per backend.

    NOTE: In Mininet-only deployments, many 'cloud' metrics (CPU/mem) are not directly observable from the controller VM.
    This struct therefore focuses on dataplane-observable stats (flows and bandwidth), and allows optional extension.
    """
    active_flows: int = 0
    bps_in: float = 0.0
    bps_out: float = 0.0
    last_seen_ts: float = 0.0
    extra: Dict[str, float] = field(default_factory=dict)


@dataclass
class Backend:
    """A backend server that can receive traffic from the VIP."""
    backend_id: str
    ip: str
    # The backend MAC and switch output port are learned at runtime via L2 learning.
    mac: Optional[str] = None
    ofport: Optional[int] = None

    # Base capacity weight (static); dynamic weights come from GA.
    base_weight: int = 1
    ga_weight: int = 1

    enabled: bool = True
    stats: BackendStats = field(default_factory=BackendStats)

    def effective_weight(self) -> int:
        return max(1, int(self.ga_weight))

    def to_dict(self) -> dict:
        return {
            "id": self.backend_id,
            "ip": self.ip,
            "mac": self.mac,
            "ofport": self.ofport,
            "base_weight": self.base_weight,
            "ga_weight": self.ga_weight,
            "enabled": self.enabled,
            "stats": {
                "active_flows": self.stats.active_flows,
                "bps_in": self.stats.bps_in,
                "bps_out": self.stats.bps_out,
                "last_seen_ts": self.stats.last_seen_ts,
                "extra": dict(self.stats.extra),
            },
        }
