from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml


@dataclass
class Backend:
    backend_id: str
    ip: str
    mac: str
    port: int
    base_weight: int = 1


@dataclass
class ControllerConfig:
    openflow_port: int = 6653
    metrics_port: int = 9100
    advertise_ip: str = "auto"


@dataclass
class VIPConfig:
    ip: str
    mac: str
    tcp_port: int = 8000


@dataclass
class GASection:
    enabled: bool = True
    interval_sec: int = 20
    population: int = 18
    generations: int = 20
    mutation_rate: float = 0.15
    elite_ratio: float = 0.2
    target_mbps: float = 20.0


@dataclass
class RRSection:
    mode: str = "smooth_weighted"


@dataclass
class AlgoConfig:
    rr: RRSection
    ga: GASection


@dataclass
class GatingConfig:
    max_mbps_tx: float = 95.0
    max_mbps_rx: float = 95.0
    max_active_flows: int = 5000


@dataclass
class AppConfig:
    vip: VIPConfig
    controller: ControllerConfig
    algorithms: AlgoConfig
    gating: GatingConfig
    backends: List[Backend]
    log_level: str = "INFO"


def load_config(path: str) -> AppConfig:
    p = Path(path)
    data = yaml.safe_load(p.read_text())

    vip = data.get("vip", {})
    ctrl = data.get("controller", {})
    rr = data.get("algorithms", {}).get("rr", {})
    ga = data.get("algorithms", {}).get("ga", {})
    gating = data.get("gating", {})
    log_level = (data.get("logging", {}) or {}).get("level", "INFO")

    vip_cfg = VIPConfig(
        ip=str(vip.get("ip", "10.0.0.100")),
        mac=str(vip.get("mac", "00:00:00:00:00:FE")),
        tcp_port=int(vip.get("tcp_port", 8000)),
    )
    ctrl_cfg = ControllerConfig(
        openflow_port=int(ctrl.get("openflow_port", 6653)),
        metrics_port=int(ctrl.get("metrics_port", 9100)),
        advertise_ip=str(ctrl.get("advertise_ip", "auto")),
    )
    rr_cfg = RRSection(mode=str(rr.get("mode", "smooth_weighted")))
    ga_cfg = GASection(
        enabled=bool(ga.get("enabled", True)),
        interval_sec=int(ga.get("interval_sec", 20)),
        population=int(ga.get("population", 18)),
        generations=int(ga.get("generations", 20)),
        mutation_rate=float(ga.get("mutation_rate", 0.15)),
        elite_ratio=float(ga.get("elite_ratio", 0.2)),
        target_mbps=float(ga.get("target_mbps", 20.0)),
    )
    algo_cfg = AlgoConfig(rr=rr_cfg, ga=ga_cfg)
    gating_cfg = GatingConfig(
        max_mbps_tx=float(gating.get("max_mbps_tx", 95.0)),
        max_mbps_rx=float(gating.get("max_mbps_rx", 95.0)),
        max_active_flows=int(gating.get("max_active_flows", 5000)),
    )

    backends: List[Backend] = []
    for b in data.get("backends", []) or []:
        backends.append(
            Backend(
                backend_id=str(b.get("id")),
                ip=str(b.get("ip")),
                mac=str(b.get("mac")),
                port=int(b.get("port", 0)),
                base_weight=int(b.get("base_weight", 1)),
            )
        )

    if not backends:
        # Fallback
        backends = [
            Backend("h2", "10.0.0.2", "00:00:00:00:00:02", 2, 1),
            Backend("h3", "10.0.0.3", "00:00:00:00:00:03", 3, 1),
            Backend("h4", "10.0.0.4", "00:00:00:00:00:04", 4, 1),
        ]

    return AppConfig(
        vip=vip_cfg,
        controller=ctrl_cfg,
        algorithms=algo_cfg,
        gating=gating_cfg,
        backends=backends,
        log_level=str(log_level),
    )
