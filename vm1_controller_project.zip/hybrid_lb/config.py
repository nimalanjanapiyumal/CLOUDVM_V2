from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

from hybrid_lb.algorithms.genetic import GAConfig
from hybrid_lb.algorithms.hybrid import Thresholds
from hybrid_lb.model import Backend


@dataclass
class ControllerConfig:
    of_listen_port: int = 6653
    rest_port: int = 8080
    metrics_port: int = 9100


@dataclass
class VipConfig:
    ip: str = "10.0.0.100"
    mac: str = "00:00:00:00:00:64"


@dataclass
class MonitoringConfig:
    stats_poll_seconds: int = 3
    state_dump_seconds: int = 5
    state_path: str = "./run/state.json"


@dataclass
class AppConfig:
    controller: ControllerConfig
    vip: VipConfig
    services: List[int]
    backends: List[Backend]
    thresholds: Thresholds
    ga: GAConfig
    ga_enabled: bool
    ga_interval_seconds: int
    monitoring: MonitoringConfig


def load_config(path: str) -> AppConfig:
    p = Path(path)
    data = yaml.safe_load(p.read_text(encoding="utf-8"))

    ctrl = data.get("controller", {}) or {}
    controller = ControllerConfig(
        of_listen_port=int(ctrl.get("of_listen_port", 6653)),
        rest_port=int(ctrl.get("rest_port", 8080)),
        metrics_port=int(ctrl.get("metrics_port", 9100)),
    )

    vipd = data.get("vip", {}) or {}
    vip = VipConfig(ip=str(vipd.get("ip", "10.0.0.100")), mac=str(vipd.get("mac", "00:00:00:00:00:64")))

    services = [int(x) for x in (data.get("services") or [8080])]

    backends = []
    for b in (data.get("backends") or []):
        backends.append(
            Backend(
                backend_id=str(b["id"]),
                ip=str(b["ip"]),
                base_weight=int(b.get("base_weight", 1)),
                ga_weight=int(b.get("base_weight", 1)),
            )
        )

    th = data.get("thresholds", {}) or {}
    thresholds = Thresholds(
        max_active_flows=int(th.get("max_active_flows", 200)),
        max_mbps_out=float(th.get("max_mbps_out", 900.0)),
    )

    gad = data.get("ga", {}) or {}
    ga_enabled = bool(gad.get("enabled", True))
    ga_interval_seconds = int(gad.get("interval_seconds", 20))
    ga = GAConfig(
        population=int(gad.get("population", 30)),
        generations=int(gad.get("generations", 40)),
        crossover_rate=float(gad.get("crossover_rate", 0.8)),
        mutation_rate=float(gad.get("mutation_rate", 0.2)),
        weight_min=int(gad.get("weight_min", 1)),
        weight_max=int(gad.get("weight_max", 10)),
        seed=int(gad.get("seed", 42)),
    )

    mon = data.get("monitoring", {}) or {}
    monitoring = MonitoringConfig(
        stats_poll_seconds=int(mon.get("stats_poll_seconds", 3)),
        state_dump_seconds=int(mon.get("state_dump_seconds", 5)),
        state_path=str(mon.get("state_path", "./run/state.json")),
    )

    return AppConfig(
        controller=controller,
        vip=vip,
        services=services,
        backends=backends,
        thresholds=thresholds,
        ga=ga,
        ga_enabled=ga_enabled,
        ga_interval_seconds=ga_interval_seconds,
        monitoring=monitoring,
    )
