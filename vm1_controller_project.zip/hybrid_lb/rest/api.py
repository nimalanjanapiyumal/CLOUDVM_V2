from __future__ import annotations

import json
import time
from typing import Any, Dict, Optional

from ryu.app.wsgi import ControllerBase, Response, route


class HybridLBRestController(ControllerBase):
    """Northbound REST API (acts as the controller's management gateway)."""

    def __init__(self, req, link, data, **config):
        super().__init__(req, link, data, **config)
        self.app = data["app"]

    @route("hybridlb", "/health", methods=["GET"])
    def health(self, req, **kwargs):
        body = {"ok": True, "ts": time.time()}
        return Response(content_type="application/json", body=json.dumps(body))

    @route("hybridlb", "/discover", methods=["GET"])
    def discover(self, req, **kwargs):
        body = self.app.discovery_payload()
        return Response(content_type="application/json", body=json.dumps(body))

    @route("hybridlb", "/status", methods=["GET"])
    def status(self, req, **kwargs):
        body = self.app.status_payload()
        return Response(content_type="application/json", body=json.dumps(body))

    @route("hybridlb", "/config/thresholds", methods=["POST"])
    def set_thresholds(self, req, **kwargs):
        try:
            data = req.json if hasattr(req, "json") else json.loads(req.body.decode("utf-8"))
        except Exception:
            data = {}

        max_flows = data.get("max_active_flows")
        max_mbps_out = data.get("max_mbps_out")
        self.app.set_thresholds(max_flows, max_mbps_out)

        body = {"ok": True, "thresholds": self.app.thresholds_payload()}
        return Response(content_type="application/json", body=json.dumps(body))

    @route("hybridlb", "/config/ga", methods=["POST"])
    def set_ga(self, req, **kwargs):
        try:
            data = req.json if hasattr(req, "json") else json.loads(req.body.decode("utf-8"))
        except Exception:
            data = {}

        enabled = data.get("enabled")
        interval = data.get("interval_seconds")
        self.app.set_ga(enabled, interval)

        body = {"ok": True, "ga": self.app.ga_payload()}
        return Response(content_type="application/json", body=json.dumps(body))
