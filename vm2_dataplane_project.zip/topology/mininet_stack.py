from __future__ import annotations

import argparse
import os
import signal
import sys
import time
from pathlib import Path

from mininet.net import Mininet
from mininet.node import RemoteController, OVSSwitch
from mininet.cli import CLI
from mininet.log import setLogLevel, info


def start_backend(host, backend_id: str, script_path: str, port: int = 8000):
    cmd = f"python3 {script_path} --id {backend_id} --bind {host.IP()} --port {port} > /tmp/{backend_id}.log 2>&1 &"
    host.cmd(cmd)
    info(f"*** Started backend {backend_id} on {host.IP()}:{port}\n")


def start_iperf_server(host, backend_id: str):
    host.cmd(f"iperf3 -s -D -p 5201 > /tmp/{backend_id}_iperf.log 2>&1")
    info(f"*** Started iperf3 server on {backend_id} ({host.IP()}:5201)\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--controller-ip", required=True)
    ap.add_argument("--controller-port", type=int, default=6653)
    ap.add_argument("--vip", default="10.0.0.100")
    ap.add_argument("--service-port", type=int, default=8000)
    ap.add_argument("--start-load", action="store_true")
    ap.add_argument("--duration", type=int, default=20)
    ap.add_argument("--rps", type=int, default=20)
    ap.add_argument("--cli", action="store_true")
    args = ap.parse_args()

    setLogLevel("info")

    repo_root = Path(__file__).resolve().parents[1]
    backend_script = str(repo_root / "services" / "backend_server.py")
    client_load_script = str(repo_root / "tools" / "client_load.py")

    net = Mininet(controller=None, switch=OVSSwitch, build=False, autoSetMacs=True)

    c0 = RemoteController("c0", ip=args.controller_ip, port=args.controller_port)
    net.addController(c0)

    s1 = net.addSwitch("s1")
    h1 = net.addHost("h1", ip="10.0.0.1/24")
    h2 = net.addHost("h2", ip="10.0.0.2/24")
    h3 = net.addHost("h3", ip="10.0.0.3/24")
    h4 = net.addHost("h4", ip="10.0.0.4/24")

    net.addLink(h1, s1)
    net.addLink(h2, s1)
    net.addLink(h3, s1)
    net.addLink(h4, s1)

    net.build()
    net.start()

    info("*** Warming up (pingAll) to learn ports/MACs\n")
    net.pingAll()

    start_backend(h2, "h2", backend_script, port=args.service_port)
    start_backend(h3, "h3", backend_script, port=args.service_port)
    start_backend(h4, "h4", backend_script, port=args.service_port)

    start_iperf_server(h2, "h2")
    start_iperf_server(h3, "h3")
    start_iperf_server(h4, "h4")

    if args.start_load:
        info("*** Starting HTTP load from h1 -> VIP\n")
        h1.cmd(f"python3 {client_load_script} --vip {args.vip} --port {args.service_port} --duration {args.duration} --rps {args.rps}")

    if args.cli:
        CLI(net)
    else:
        info("*** Simulation running (press Ctrl+C to stop)\n")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass

    net.stop()


if __name__ == "__main__":
    main()
