#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import signal
import sys
import time
from pathlib import Path

from mininet.cli import CLI
from mininet.link import TCLink
from mininet.log import setLogLevel
from mininet.net import Mininet
from mininet.node import OVSSwitch, RemoteController
from mininet.topo import Topo


class SingleSwitchTopo(Topo):
    def build(self):  # noqa: N802
        s1 = self.addSwitch("s1")
        h1 = self.addHost("h1", ip="10.0.0.1/24")
        h2 = self.addHost("h2", ip="10.0.0.2/24")
        h3 = self.addHost("h3", ip="10.0.0.3/24")
        h4 = self.addHost("h4", ip="10.0.0.4/24")

        for h in (h1, h2, h3, h4):
            self.addLink(h, s1)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--controller-ip", required=True, help="Controller VM IP (Ryu OpenFlow endpoint)")
    ap.add_argument("--controller-port", type=int, default=6653, help="Controller OpenFlow TCP port")
    ap.add_argument("--vip", default="10.0.0.100", help="VIP IP address (handled by controller)")
    ap.add_argument("--http-port", type=int, default=8080, help="Backend HTTP port (load balanced)")
    ap.add_argument("--start-load", action="store_true", help="Start HTTP benchmark from h1 automatically")
    ap.add_argument("--duration", type=int, default=60, help="Load duration (if --start-load)")
    ap.add_argument("--concurrency", type=int, default=20, help="Load concurrency (if --start-load)")
    ap.add_argument("--cli", action="store_true", help="Drop into Mininet CLI after setup")
    args = ap.parse_args()

    setLogLevel("info")

    topo = SingleSwitchTopo()
    net = Mininet(
        topo=topo,
        controller=None,
        switch=OVSSwitch,
        link=TCLink,
        autoSetMacs=True,
        autoStaticArp=False,
        build=True,
    )

    c0 = net.addController("c0", controller=RemoteController, ip=args.controller_ip, port=args.controller_port)

    net.start()

    # Enforce OpenFlow 1.3 on the bridge.
    s1 = net.get("s1")
    s1.cmd("ovs-vsctl set bridge s1 protocols=OpenFlow13")

    # Populate ARP/MAC tables (helps controller learn backend ports+MACs).
    net.pingAll(timeout="1")

    # Start backend servers + iperf3 servers
    proj_root = Path(__file__).resolve().parents[1]
    backend_server = proj_root / "services" / "backend_server.py"
    client_load = proj_root / "tools" / "client_load.py"

    h2, h3, h4 = net.get("h2"), net.get("h3"), net.get("h4")
    backends = [(h2, "b1"), (h3, "b2"), (h4, "b3")]

    for h, bid in backends:
        h.cmd(f"python3 {backend_server} --id {bid} --port {args.http_port} > /tmp/{bid}_http.log 2>&1 &")
        h.cmd(f"iperf3 -s -p 5201 > /tmp/{bid}_iperf.log 2>&1 &")

    print("\n[dataplane] Backends started:")
    for h, bid in backends:
        print(f"  {bid}: {h.IP()}:{args.http_port}")

    # Optionally start load from h1
    if args.start_load:
        h1 = net.get("h1")
        print(f"\n[dataplane] Starting HTTP load from h1 to VIP {args.vip}:{args.http_port} ...")
        h1.cmd(f"python3 {client_load} --vip {args.vip} --port {args.http_port} --duration {args.duration} --concurrency {args.concurrency} | tee /tmp/client_load.log")

    print("\n[dataplane] Setup complete.")
    print(f"[dataplane] Try: h1 curl -s http://{args.vip}:{args.http_port}/")
    print("[dataplane] Logs: /tmp/b1_http.log, /tmp/b2_http.log, /tmp/b3_http.log, /tmp/client_load.log")

    if args.cli:
        CLI(net)

    net.stop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
