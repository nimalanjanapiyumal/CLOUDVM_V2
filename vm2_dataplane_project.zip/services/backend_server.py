#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Tuple


class _State:
    def __init__(self, backend_id: str) -> None:
        self.backend_id = backend_id
        self.lock = threading.Lock()
        self.requests_total = 0
        self.started_ts = time.time()

    def inc(self) -> int:
        with self.lock:
            self.requests_total += 1
            return self.requests_total

    def snapshot(self) -> dict:
        with self.lock:
            return {
                "backend_id": self.backend_id,
                "requests_total": self.requests_total,
                "uptime_seconds": time.time() - self.started_ts,
                "ts": time.time(),
            }


class BackendHandler(BaseHTTPRequestHandler):
    state: _State = None  # type: ignore

    def _json(self, code: int, payload: dict) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)

    def _text(self, code: int, text: str, content_type: str = "text/plain") -> None:
        body = text.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):  # noqa: N802
        if self.path in ("/", "/index.html"):
            n = self.state.inc()
            self._json(200, {"message": "ok", **self.state.snapshot()})
            return
        if self.path in ("/health", "/healthz"):
            self._text(200, "OK\n")
            return
        if self.path in ("/stats", "/status"):
            self._json(200, self.state.snapshot())
            return
        if self.path == "/metrics":
            snap = self.state.snapshot()
            # Minimal Prometheus-style metrics
            metrics = []
            metrics.append("# HELP backend_requests_total Total HTTP requests served by this backend")
            metrics.append("# TYPE backend_requests_total counter")
            metrics.append(f'backend_requests_total{{backend_id="{snap["backend_id"]}"}} {snap["requests_total"]}')
            metrics.append("# HELP backend_uptime_seconds Uptime of backend server")
            metrics.append("# TYPE backend_uptime_seconds gauge")
            metrics.append(f'backend_uptime_seconds{{backend_id="{snap["backend_id"]}"}} {snap["uptime_seconds"]:.3f}')
            self._text(200, "\n".join(metrics) + "\n")
            return

        self._json(404, {"error": "not_found", "path": self.path})

    def log_message(self, fmt: str, *args) -> None:
        # Keep host logs quieter; comment this line if you want verbose logs.
        return


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--id", required=True, help="Backend ID (e.g., b1)")
    ap.add_argument("--bind", default="0.0.0.0", help="Bind address")
    ap.add_argument("--port", type=int, default=8080, help="TCP port")
    args = ap.parse_args()

    state = _State(args.id)
    BackendHandler.state = state

    httpd = ThreadingHTTPServer((args.bind, args.port), BackendHandler)
    print(f"[backend_server] id={args.id} listening on {args.bind}:{args.port}", flush=True)

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
