from __future__ import annotations

import argparse
import json
import socket
import time
from http.server import BaseHTTPRequestHandler, HTTPServer


class Handler(BaseHTTPRequestHandler):
    server_version = "HybridLBBackend/1.0"

    def do_GET(self):
        payload = {
            "backend_id": self.server.backend_id,
            "host": socket.gethostname(),
            "time": time.time(),
            "path": self.path,
        }
        data = json.dumps(payload).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, fmt, *args):
        # quieter
        return


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bind", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--id", dest="backend_id", default="backend")
    args = ap.parse_args()

    httpd = HTTPServer((args.bind, args.port), Handler)
    httpd.backend_id = args.backend_id
    print(f"[backend_server] {args.backend_id} listening on {args.bind}:{args.port}", flush=True)
    httpd.serve_forever()


if __name__ == "__main__":
    main()
