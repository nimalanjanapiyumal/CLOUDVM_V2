# VM2 - SDN Data Plane (Mininet + OVS) + Demo Backends

This package runs the data plane described in the proposal:
- Mininet topology with OVS switch
- Backend demo servers (HTTP on port 8080, iperf3 on port 5201)
- Optional traffic generation from a Mininet client host

It is intended to be deployed on a dedicated "Data Plane VM".
