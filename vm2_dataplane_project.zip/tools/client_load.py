#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import statistics
import threading
import time
import urllib.error
import urllib.request
from collections import Counter
from typing import List, Tuple


def _http_get(url: str, timeout: float) -> Tuple[bool, float, str]:
    """Return (ok, latency_seconds, backend_id_or_error)."""
    start = time.perf_counter()
    try:
        req = urllib.request.Request(url, headers={"Connection": "close", "User-Agent": "hybrid-lb-client"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
        latency = time.perf_counter() - start
        try:
            data = json.loads(raw.decode("utf-8"))
            backend_id = data.get("backend_id") or data.get("id") or "unknown"
            return True, latency, str(backend_id)
        except Exception:
            return True, latency, "unparsed"
    except Exception as e:
        latency = time.perf_counter() - start
        return False, latency, f"error:{type(e).__name__}"


def percentile(values: List[float], p: float) -> float:
    if not values:
        return 0.0
    values_sorted = sorted(values)
    k = (len(values_sorted) - 1) * (p / 100.0)
    f = int(k)
    c = min(f + 1, len(values_sorted) - 1)
    if f == c:
        return values_sorted[f]
    d0 = values_sorted[f] * (c - k)
    d1 = values_sorted[c] * (k - f)
    return d0 + d1


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--vip", default="10.0.0.100", help="VIP IP")
    ap.add_argument("--port", type=int, default=8080, help="VIP service port")
    ap.add_argument("--duration", type=int, default=60, help="Duration seconds")
    ap.add_argument("--concurrency", type=int, default=20, help="Number of client threads")
    ap.add_argument("--timeout", type=float, default=1.5, help="Per-request timeout seconds")
    ap.add_argument("--sla_ms", type=float, default=200.0, help="SLA latency threshold (ms) for compliance")
    args = ap.parse_args()

    url = f"http://{args.vip}:{args.port}/"
    end_ts = time.time() + args.duration

    latencies: List[float] = []
    ok_counter = Counter()
    err_counter = Counter()
    lock = threading.Lock()

    def worker(tid: int) -> None:
        while time.time() < end_ts:
            ok, lat, tag = _http_get(url, args.timeout)
            with lock:
                latencies.append(lat)
                if ok:
                    ok_counter[tag] += 1
                else:
                    err_counter[tag] += 1

    threads = [threading.Thread(target=worker, args=(i,), daemon=True) for i in range(args.concurrency)]
    start = time.time()
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    elapsed = time.time() - start

    total = sum(ok_counter.values()) + sum(err_counter.values())
    sla_s = args.sla_ms / 1000.0
    sla_ok = sum(1 for x in latencies if x <= sla_s)

    print("\n=== Hybrid LB HTTP Benchmark ===")
    print(f"Target: {url}")
    print(f"Total requests: {total} (ok={sum(ok_counter.values())}, errors={sum(err_counter.values())})")
    print(f"Elapsed: {elapsed:.2f}s  |  RPS: {total/elapsed:.2f}")

    if latencies:
        p50 = percentile(latencies, 50)
        p95 = percentile(latencies, 95)
        p99 = percentile(latencies, 99)
        print(f"Latency (ms): p50={p50*1000:.2f}  p95={p95*1000:.2f}  p99={p99*1000:.2f}  max={max(latencies)*1000:.2f}")
        print(f"SLA <= {args.sla_ms:.0f}ms: {sla_ok}/{len(latencies)} ({sla_ok/len(latencies)*100:.2f}%)")
    else:
        print("No latency samples collected.")

    if ok_counter:
        print("\nBackend distribution (from response backend_id):")
        for k, v in ok_counter.most_common():
            print(f"  {k}: {v} ({v/sum(ok_counter.values())*100:.2f}%)")

    if err_counter:
        print("\nErrors:")
        for k, v in err_counter.most_common():
            print(f"  {k}: {v}")

    print("=== End ===\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
