from __future__ import annotations

import argparse
import statistics
import time
import urllib.request


def percentile(sorted_vals, p: float) -> float:
    if not sorted_vals:
        return float("nan")
    if p <= 0:
        return sorted_vals[0]
    if p >= 100:
        return sorted_vals[-1]
    k = (len(sorted_vals) - 1) * (p / 100.0)
    f = int(k)
    c = min(f + 1, len(sorted_vals) - 1)
    if f == c:
        return sorted_vals[f]
    d0 = sorted_vals[f] * (c - k)
    d1 = sorted_vals[c] * (k - f)
    return d0 + d1


def main():
    ap = argparse.ArgumentParser(description="Simple HTTP load generator for VIP")
    ap.add_argument("--vip", default="10.0.0.100")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--duration", type=int, default=20)
    ap.add_argument("--rps", type=int, default=20)
    ap.add_argument("--sla_ms", type=int, default=200)
    args = ap.parse_args()

    url = f"http://{args.vip}:{args.port}/"
    lat = []
    ok = 0
    total = 0
    end = time.time() + args.duration
    interval = 1.0 / max(1, args.rps)

    print(f"[client_load] Target={url} duration={args.duration}s rps={args.rps} SLA={args.sla_ms}ms", flush=True)

    while time.time() < end:
        t0 = time.perf_counter()
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                _ = r.read(512)
            dt = (time.perf_counter() - t0) * 1000.0
            lat.append(dt)
            ok += 1
        except Exception:
            dt = (time.perf_counter() - t0) * 1000.0
            lat.append(dt)
        total += 1
        # pace
        t_sleep = interval - (time.perf_counter() - t0)
        if t_sleep > 0:
            time.sleep(t_sleep)

    lat_sorted = sorted(lat)
    p50 = percentile(lat_sorted, 50)
    p95 = percentile(lat_sorted, 95)
    p99 = percentile(lat_sorted, 99)
    mean = statistics.mean(lat_sorted) if lat_sorted else float("nan")

    sla_ok = sum(1 for x in lat_sorted if x <= args.sla_ms)
    sla_pct = (sla_ok / len(lat_sorted) * 100.0) if lat_sorted else 0.0

    print("\n=== Results ===")
    print(f"requests_total={total} requests_ok={ok} ok_rate={(ok/total*100.0 if total else 0):.1f}%")
    print(f"latency_ms_mean={mean:.2f} p50={p50:.2f} p95={p95:.2f} p99={p99:.2f}")
    print(f"sla_{args.sla_ms}ms_compliance={sla_pct:.2f}%")

if __name__ == "__main__":
    main()
