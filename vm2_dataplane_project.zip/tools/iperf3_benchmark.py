from __future__ import annotations

import argparse
import json
import subprocess
import sys


def run(cmd: list[str]) -> str:
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if p.returncode != 0:
        raise RuntimeError(f"Command failed: {' '.join(cmd)}\n{p.stdout}")
    return p.stdout


def main():
    ap = argparse.ArgumentParser(description="Run an iperf3 client test")
    ap.add_argument("--server", required=True, help="iperf3 server IP")
    ap.add_argument("--time", type=int, default=10)
    ap.add_argument("--parallel", type=int, default=1)
    args = ap.parse_args()

    cmd = ["iperf3", "-c", args.server, "-t", str(args.time), "-P", str(args.parallel), "-J"]
    out = run(cmd)
    js = json.loads(out)
    bps = js["end"]["sum_received"]["bits_per_second"]
    print(f"throughput_bps={bps:.0f}")
    print(f"throughput_mbps={bps/1e6:.2f}")

if __name__ == "__main__":
    main()
