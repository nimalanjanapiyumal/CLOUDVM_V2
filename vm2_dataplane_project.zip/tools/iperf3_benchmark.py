#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
import sys
import time


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--server", default="10.0.0.100", help="Target IP (VIP or backend)")
    ap.add_argument("--port", type=int, default=5201, help="iperf3 server port")
    ap.add_argument("--seconds", type=int, default=10, help="Test duration")
    ap.add_argument("--parallel", type=int, default=1, help="Number of parallel streams")
    args = ap.parse_args()

    cmd = [
        "iperf3",
        "-c", args.server,
        "-p", str(args.port),
        "-t", str(args.seconds),
        "-P", str(args.parallel),
        "--json",
    ]
    print(f"[iperf3_benchmark] Running: {' '.join(cmd)}", flush=True)
    try:
        cp = subprocess.run(cmd, check=False, capture_output=True, text=True)
    except FileNotFoundError:
        print("[iperf3_benchmark] ERROR: iperf3 not found.", file=sys.stderr)
        return 2

    if cp.returncode != 0:
        print(cp.stdout)
        print(cp.stderr, file=sys.stderr)
        return cp.returncode

    print(cp.stdout)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
